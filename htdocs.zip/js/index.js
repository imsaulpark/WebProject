

function find_id_pw() { //위치 left=500, top=400 에서 열리는 팝업창
	//var url;
	window.open("../html/find_ID_PW.php",'popUpWindow','height=800,width=1200,left=300,top=250,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');

}
